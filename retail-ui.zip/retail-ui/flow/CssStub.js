/* @flow */

export default ({}: {[_: string]: string});
