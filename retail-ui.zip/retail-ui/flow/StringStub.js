/* @flow */

export default ('': string);
