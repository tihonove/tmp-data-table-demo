Для быстрого начала есть проект-стартер:
https://git.skbkontur.ru/catalogue/retail-ui-starter#tab-readme.

Чтобы начать со стартером:
```bash
$ git clone git@git.skbkontur.ru:catalogue/retail-ui-starter.git
$ npm install
$ npm start
```

Теперь приложение доступно на http://localhost:8080.
