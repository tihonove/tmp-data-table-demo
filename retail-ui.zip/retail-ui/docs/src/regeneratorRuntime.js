// Remove this when https://github.com/facebook/regenerator/pull/249 is merged.
global.regeneratorRuntime = null;
require('regenerator/packages/regenerator-runtime/runtime');
