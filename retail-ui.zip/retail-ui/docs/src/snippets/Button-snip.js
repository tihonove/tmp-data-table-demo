ReactDOM.render(
  <Gapped gap={10}>
    <Button>Default</Button>
    <Button use="primary">Primary</Button>
    <Button use="success">Success</Button>
    <Button use="danger">Danger</Button>
    <Button use="pay">Pay</Button>
  </Gapped>,
  mountNode
);
