var items = [
  'Grey Face',
  'Grey Space',
  'Kappa',
  'Keepo',
  'Resident Sleeper',
];

ReactDOM.render(unc(<Autocomplete source={items} />, ''), mountNode);
