ReactDOM.render(
  <Center style={{background: '#fdd', height: 150}}>
    <div style={{background: 'black', width: 30, height: 30}} />
  </Center>,
  mountNode
);
