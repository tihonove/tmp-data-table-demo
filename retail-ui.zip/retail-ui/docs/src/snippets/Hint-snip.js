ReactDOM.render((
  <Hint text="My whole goal as a poet's to be relaxed in orbit.">
    Fast Lane
  </Hint>
), mountNode);
