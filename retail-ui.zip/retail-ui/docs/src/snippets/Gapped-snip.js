ReactDOM.render(
  <Gapped gap={20}>
    <span>10</span>
    <span>20</span>
  </Gapped>,
  mountNode
);
