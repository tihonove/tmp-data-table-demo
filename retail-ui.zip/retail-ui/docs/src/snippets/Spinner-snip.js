ReactDOM.render(<Spinner type="big" caption="думаю" />, mountNode);
