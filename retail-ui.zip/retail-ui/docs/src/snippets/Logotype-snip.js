ReactDOM.render((
  <Gapped vertical>
    <Logotype suffix="edi" color="#1E79BE"/>
    <Logotype suffix="бухгалтерия" color="#A23A99"/>
    <Logotype suffix="диадок" color="#1fab90"/>
    <Logotype suffix="экстерн" color="#F15600"/>
  </Gapped>
), mountNode);
