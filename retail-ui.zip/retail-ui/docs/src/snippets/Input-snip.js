ReactDOM.render(<Input leftIcon={<Icon name="search" />} />, mountNode);
