ReactDOM.render(
  <div>
    <Radio />
    <Radio disabled />
    <Radio checked />
    <Radio focused />
    <Radio focused checked />
  </div>,
  mountNode
);
