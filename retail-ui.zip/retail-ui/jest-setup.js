import Upgrades from './lib/Upgrades';

Upgrades.enableHeight34();
