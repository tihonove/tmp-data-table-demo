import ReactTesting from './ReactTesting';

global.ReactTesting = ReactTesting;
