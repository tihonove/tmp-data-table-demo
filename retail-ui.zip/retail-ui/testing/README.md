Experimental tool for testing react apps using Selenium.
