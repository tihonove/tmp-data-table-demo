module.exports = require('./Kladr').default;
