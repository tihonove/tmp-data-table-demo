import Logotype from './Logotype';
module.exports = Logotype;
