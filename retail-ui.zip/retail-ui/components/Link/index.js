import Link from './Link';
module.exports = Link;
