import Gapped from './Gapped';
module.exports = Gapped;
