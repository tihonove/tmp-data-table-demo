import Modal from './Modal';
module.exports = Modal;
