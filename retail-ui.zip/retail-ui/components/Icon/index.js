module.exports = require('./Icon');
