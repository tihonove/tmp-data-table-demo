module.exports = require('./Icon');
