import Tooltip from './Tooltip';
module.exports = Tooltip;
