import Center from './Center';
module.exports = Center;
