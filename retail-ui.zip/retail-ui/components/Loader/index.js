import Loader from './Loader.js';
module.exports = Loader;
