import Spinner from './Spinner';
module.exports = Spinner;
