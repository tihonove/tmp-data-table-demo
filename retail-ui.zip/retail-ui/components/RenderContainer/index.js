import RenderContainer from './RenderContainer';
module.exports = RenderContainer;
