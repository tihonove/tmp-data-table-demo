import PhoneInput from './PhoneInput';
module.exports = PhoneInput;
