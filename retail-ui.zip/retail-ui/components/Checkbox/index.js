import Checkbox from './Checkbox';
module.exports = Checkbox;
