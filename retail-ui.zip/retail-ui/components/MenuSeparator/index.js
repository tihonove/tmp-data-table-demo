// @flow

import MenuSeparator from './MenuSeparator';
module.exports = MenuSeparator;
