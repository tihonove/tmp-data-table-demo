import InputLikeText from './InputLikeText';

module.exports = InputLikeText;
