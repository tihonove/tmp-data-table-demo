import Sticky from './Sticky';
module.exports = Sticky;
