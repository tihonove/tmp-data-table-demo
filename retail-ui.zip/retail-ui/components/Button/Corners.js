// @flow

export default {
  TOP_LEFT: 1,
  TOP_RIGHT: 2,
  BOTTOM_RIGHT: 4,
  BOTTOM_LEFT: 8,
};
