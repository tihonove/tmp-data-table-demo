import FxInput from './FxInput';
module.exports = FxInput;
