import Hint from './Hint';
module.exports = Hint;
